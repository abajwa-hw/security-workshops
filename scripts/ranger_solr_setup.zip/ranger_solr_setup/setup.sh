#!/bin/bash
#This script downloads Solr and sets up Solr for Ranger Audit Server
curr_dir=`pwd`

. ./install.properties

#Current timestamp
ts=$(date +"%m%d%y%H%M%S")

#Validate all variables
if [ "$SOLR_INSTALL_FOLDER" = "" ]; then
    echo "Error: SOLR_INSTALL_FOLDER not set"
    exit 1
fi

if [ "$SOLR_RANGER_HOME" = "" ]; then
    echo "Error: SOLR_RANGER_HOME not set"
    exit 1
fi

if [ "$SOLR_RANGER_PORT" = "" ]; then
    echo "Error: SOLR_RANGER_PORT not set"
    exit 1
fi

if [ "$SOLR_RANGER_DATA_FOLDER" = "" ]; then
    echo "Error: SOLR_RANGER_DATA_FOLDER not set"
    exit 1
fi

if [ "$SOLR_INSTALL" = "true" -a "$SOLR_DOWNLOAD_URL" = "" ]; then
    echo "Error: If SOLR_INSTALL=true, then SOLR_DOWNLOAD_URL can't be empty"
    exit 1
fi

#Download and install Solr if needed
if [ "$SOLR_INSTALL" = "true" ]; then
    if [ -d $SOLR_INSTALL_FOLDER ]; then
	echo "`date`|WARN|$SOLR_INSTALL_FOLDER exists. Moving to ${SOLR_INSTALL_FOLDER}.bk.${ts}"
	mv $SOLR_INSTALL_FOLDER ${SOLR_INSTALL_FOLDER}.bk.${ts}
    fi
    
    echo "`date`|INFO|Downloading solr from $SOLR_DOWNLOAD_URL"
    #Temporary create a folder to untar the folder
    tmp_folder=/tmp/solr_untar_${ts}
    mkdir -p ${tmp_folder}
    cd ${tmp_folder}
    wget $SOLR_DOWNLOAD_URL
    #Assuming this is a new folder and there will be only one file
    tgz_file=`ls *z`
    if [ ! -f $tgz_file ]; then
	echo "`date`|ERROR|Downloaded file <`pwd`/$tgz_file> not found"
	exit 1
    fi
    
    mkdir tmp
    tar xfz $tgz_file -C tmp
    cd tmp
    
    #Assuming there will only one folder begining with "s"
    solr_folder=`ls | grep "^solr"`
    
    if [ ! -d $solr_folder ]; then
	echo "`date`|ERROR|Solr temporary folder `pwd`/<$solr_folder> not found"
	exit 1
    fi
    mv $solr_folder $SOLR_INSTALL_FOLDER
    rm -rf $tmp_folder
    echo "`date`|INFO|Installed Solr in $SOLR_INSTALL_FOLDER"
fi

if [ ! -d $SOLR_INSTALL_FOLDER ]; then
    echo "`date`|ERROR|$SOLR_INSTALL_FOLDER not found. Check \$SOLR_INSTALL_FOLDER"
    exit 1
fi

########## At this point, we have the Solr installed folder ####

if [ -d $SOLR_RANGER_HOME ]; then
    echo "`date`|WARN|Solr Ranger Home <$SOLR_RANGER_HOME> exists. Moving to ${SOLR_RANGER_HOME}.bk.${ts}"
    mv $SOLR_RANGER_HOME ${SOLR_RANGER_HOME}.bk.${ts}
fi

mkdir -p $SOLR_RANGER_HOME
if [ ! -d $SOLR_RANGER_HOME ]; then
    echo "`date`|ERROR|Solr Ranger Home folder <$SOLR_RANGER_HOME> could not be created"
    exit 1
fi

######### Copy the Solr config file for Ranger ######
cd $curr_dir
echo "`date`|INFO|Copying Ranger Audit Server configuration to $SOLR_RANGER_HOME"
cp -r ranger_audit_server/* $SOLR_RANGER_HOME
sed  "s#__ranger_audits_data_folder__#$SOLR_RANGER_DATA_FOLDER#g" $SOLR_RANGER_HOME/ranger_audits/core.properties.template > $SOLR_RANGER_HOME/ranger_audits/core.properties

sed  "s#__RANGER_AUDITS_DATA_FOLDER__#$SOLR_RANGER_DATA_FOLDER#g" $SOLR_RANGER_HOME/ranger_audits/core.properties.template > $SOLR_RANGER_HOME/ranger_audits/core.properties
sed  -e "s#__SOLR_MAX_MEM__#$SOLR_MAX_MEM#g" -e "s#__SOLR_INSTALL_DIR__#$SOLR_INSTALL_FOLDER#g" -e "s#__SOLR_RANGER_HOME__#$SOLR_RANGER_HOME#g" -e "s#__SOLR_PORT__#$SOLR_RANGER_PORT#g" $SOLR_RANGER_HOME/scripts/start_solr.sh.template > $SOLR_RANGER_HOME/scripts/start_solr.sh
sed  -e "s#__SOLR_INSTALL_DIR__#$SOLR_INSTALL_FOLDER#g" -e "s#__SOLR_PORT__#$SOLR_RANGER_PORT#g" $SOLR_RANGER_HOME/scripts/stop_solr.sh.template > $SOLR_RANGER_HOME/scripts/stop_solr.sh
chmod a+x $SOLR_RANGER_HOME/scripts/*.sh

echo "`date`|INFO|Done configuring Solr for Apache Ranger"
